# SentiMax - Next-Generation Sentiment-Analysis with spaCy for german
## This is currently under construction
### Describtion and updates will follow soon
